<?php echo e($slot); ?>

<?php /**PATH /Users/maxpro/Desktop/code/playground/new-cms-system/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>